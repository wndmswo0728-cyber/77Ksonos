# SONOS · TANOS · TANS 77 K 및 300 K 결과와 ATLAS 읽기 덱

전하 수송을 계산해 둔 패키지다. 이 패키지를 여는 데 Python 설치는 필요 없다.

1. ZIP을 전체 압축 해제한다.
2. 77 K TANS에서 PF와 호핑을 둘 다 켠 결과를 보려면 `cases/TANS_77K/PF_on_Hopping_on/`을 연다.
3. 전하–시간 그래프는 `program_netcharge_model.dat`(PGM), `erase_netcharge_model.dat`(Erase), `program_retention_model.dat`(PGM 후 Retention), `erase_retention_model.dat`(Erase 후 Retention)를 사용한다. `.dat`는 시간(s)과 전하(C) 2열이고, 이름이 같은 `.log`는 탭 구분 계산 데이터다.
4. I–V와 구조 파일을 얻으려면, 위 조건 폴더를 DeckBuild 작업 폴더로 지정한 후 `ALL_IV.in`을 실행한다. `INITIAL`, `PGM`, `ERS`, `RET`, `ERS_RET` 상태별 `.str`와 `*_IV.log`를 쓰도록 구성했다. `RET`는 PGM 후, `ERS_RET`는 Erase 후 보존 상태다. 개별 `.in`도 따로 실행할 수 있다.

세 구조, 두 온도, PF와 호핑의 네 가지 ON/OFF 조합으로 총 24개 폴더가 들어 있다. 다른 온도나 구조는 `cases` 아래에서 고르고, 같은 온도에서 PF 또는 호핑 중 하나만 바꾸려면 조건 폴더만 바꾼다. `model_switch_comparison.csv`에 각 상태의 전하와 정전기적 문턱전압 이동 추정값을 모아 두었다.

TANS에만 Si/Si₃N₄ 계면의 1 nm 자연산화막을 가정했다. 각 `.in`의 고정 체적 전하는 이미 구해 둔 수송 계산의 결과다. ATLAS 5.36.0.R 실행과 읽기 해의 수렴은 검증 전이다. 사용 중인 DeckBuild에서 엔진 옵션을 점검할 때는 `00_CHECK.in`을 실행한다.
