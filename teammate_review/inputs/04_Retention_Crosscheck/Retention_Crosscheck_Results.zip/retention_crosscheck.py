"""Reproduce the exported-data retention cross-check; not a transport simulator.
Usage: python retention_crosscheck.py ChargeTrap_77K_Ready_To_Run.zip --output retention_review
Plots require numpy and matplotlib. Numeric results describe the supplied exports only.
"""
import argparse
import ast
import csv
import hashlib
import io
import json
from pathlib import Path
import zipfile
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

DEVICES = ['SONOS', 'TANOS', 'TANS']
SWITCHES = [(False, False), (True, False), (False, True), (True, True)]
FRACTIONS = [f'{s}_fraction_{i}' for s in ['e', 'h'] for i in range(1, 5)]
QE = 1.602176634e-19
AREA = 1e-12
DY = 1.75e-9


def table(headers, rows):
    return '\n'.join(['| ' + ' | '.join(headers) + ' |',
                      '| ' + ' | '.join(['---'] * len(headers)) + ' |'] +
                     ['| ' + ' | '.join(str(x) for x in row) + ' |' for row in rows])


def half_time(t, r):
    for i in range(1, len(t)):
        if r[i-1] > .5 >= r[i]:
            w = (.5-r[i-1])/(r[i]-r[i-1])
            if t[i-1] > 0:
                return float(np.exp(np.log(t[i-1]) + w*np.log(t[i]/t[i-1])))
            return float(t[i-1]+w*(t[i]-t[i-1]))
    return None


def run(archive, output):
    output.mkdir(parents=True, exist_ok=True)
    z = zipfile.ZipFile(archive)
    cache = {}
    def read(name):
        return z.read(name).decode('utf-8-sig')
    def rows(base, stage):
        name = base+stage+'_model.log'
        if name not in cache:
            cache[name] = list(csv.DictReader(io.StringIO(read(name)), delimiter='\t'))
        return cache[name]
    def path(d, t, pf, hop):
        return f'cases/{d}_{t}K/PF_{"on" if pf else "off"}_Hopping_{"on" if hop else "off"}/'
    def vector(rs, name):
        return np.array([float(r[name]) for r in rs])
    initial_vectors = []
    metrics = []
    stage_checks = []
    parameter_checks = []
    parameter_data = {}
    initial_q = []
    reconstruction_error = 0.0
    dat_q_error = 0.0
    dat_t_relative_error = 0.0
    max_off_hop = 0.0
    all_matched_zero_gate = True
    for d in DEVICES:
        for temp in [77, 300]:
            for pf, hop in SWITCHES:
                b = path(d, temp, pf, hop)
                options = ast.parse(read(b+'parameters.txt').splitlines()[0], mode='eval').body
                parameter_data[d,temp,pf,hop] = {k.arg: ast.literal_eval(k.value) for k in options.keywords}
                pars=parameter_data[d,temp,pf,hop]
                if pars['temperature']!=temp or pars['pf']!=pf or pars['hopping']!=hop:
                    raise ValueError('Folder/parameter mismatch: '+b)
                p, e, pr, er, m, empty = [rows(b, s) for s in ['program_netcharge', 'erase_netcharge',
                    'program_retention', 'erase_retention', 'matched_retention', 'matched_empty']]
                initial_vectors.append(tuple(float(m[0][k]) for k in FRACTIONS))
                initial_q.append(float(m[0]['net_C']))
                all_matched_zero_gate &= all(float(r['Vg_V']) == 0 for r in m)
                for label, first, second in [('PGM_to_ERS',p,e), ('PGM_to_retention',p,pr), ('ERS_to_retention',e,er)]:
                    dq = abs(float(first[-1]['net_C'])-float(second[0]['net_C']))
                    df = max(abs(float(first[-1][k])-float(second[0][k])) for k in FRACTIONS)
                    stage_checks.append(dict(device=d,temperature_K=temp,pf=int(pf),hopping=int(hop),
                                             transition=label,charge_error_C=dq,max_fraction_error=df))
                t, q, te, qe = vector(m,'time_s'),vector(m,'net_C'),vector(empty,'time_s'),vector(empty,'net_C')
                if not np.array_equal(t,te):
                    raise ValueError('Matched/empty time grids differ: '+b)
                contrast = (q-qe)/(q[0]-qe[0])
                metric = dict(device=d,temperature_K=temp,pf=int(pf),hopping=int(hop),
                    matched_Q0_fC=q[0]*1e15,matched_Qfinal_fC=q[-1]*1e15,empty_Qfinal_fC=qe[-1]*1e15,
                    final_contrast=contrast[-1],contrast_half_time_s=half_time(t,contrast),
                    PGM_fC=float(p[-1]['net_C'])*1e15,ERS_fC=float(e[-1]['net_C'])*1e15,
                    PGM_RET_final_fC=float(pr[-1]['net_C'])*1e15,ERS_RET_final_fC=float(er[-1]['net_C'])*1e15)
                for target in [1e-4,1,1e3,1e5]:
                    i = int(np.argmin(abs(t-target)))
                    metric[f'Q_at_{target:g}s_fC'] = q[i]*1e15
                    metric[f'contrast_at_{target:g}s'] = contrast[i]
                metrics.append(metric)
                for stage in ['program_netcharge','erase_netcharge','program_retention','erase_retention',
                              'matched_retention','matched_empty','pulse_empty']:
                    rs = rows(b,stage)
                    for r in rs:
                        electrons = sum(float(r[f'e_fraction_{i}']) for i in range(1,5))*5e19
                        holes = sum(float(r[f'h_fraction_{i}']) for i in range(1,5))*1e19
                        qc = QE*(holes-electrons)*1e6*DY*AREA
                        reconstruction_error = max(reconstruction_error,abs(qc-float(r['net_C'])))
                        if not hop:
                            max_off_hop = max(max_off_hop,max(abs(float(v)) for k,v in r.items() if k.startswith('hop_')))
                    points=[]
                    for line in read(b+stage+'_model.dat').splitlines():
                        fields=line.split()
                        if len(fields)==2:
                            try:
                                points.append(tuple(map(float,fields)))
                            except ValueError:
                                pass
                    if len(points)!=len(rs):
                        raise ValueError('DAT/LOG count mismatch: '+b+stage)
                    for (td,qd),r in zip(points,rs):
                        tr=float(r['time_s'])
                        dat_q_error=max(dat_q_error,abs(qd-float(r['net_C'])))
                        if tr: dat_t_relative_error=max(dat_t_relative_error,abs(td-tr)/abs(tr))
    for d in DEVICES:
        for temp in [77,300]:
            reference=parameter_data[d,temp,False,False]
            for pf,hop in SWITCHES:
                changed=sorted(k for k,v in parameter_data[d,temp,pf,hop].items() if v!=reference[k])
                expected=sorted((['pf'] if pf else [])+(['hopping'] if hop else []))
                parameter_checks.append(dict(device=d,temperature_K=temp,pf=int(pf),hopping=int(hop),
                                             changed_keys=','.join(changed),switch_only=changed==expected))
    for filename, data in [('case_metrics.csv',metrics),('state_transitions.csv',stage_checks),
                           ('parameter_checks.csv',parameter_checks)]:
        with (output/filename).open('w',newline='',encoding='utf-8-sig') as f:
            w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
    overview_figs=[]
    for d in DEVICES:
        fig,ax=plt.subplots(figsize=(10,5.8))
        for temp,stage,color in [(77,'program_retention','royalblue'),(77,'erase_retention','tomato'),
                                  (300,'program_retention','darkgoldenrod'),(300,'erase_retention','forestgreen')]:
            r=rows(path(d,temp,True,True),stage);t=vector(r,'time_s');q=vector(r,'net_C')
            ax.semilogx(t[t>0],q[t>0]*1e15,color=color,label=f'{temp} K, {stage.replace("_"," ")}')
        er=rows(path(d,300,True,True),'pulse_empty');t=vector(er,'time_s')
        ax.semilogx(t[t>0],vector(er,'net_C')[t>0]*1e15,color='black',ls=':',lw=1.6,label='300 K, initially empty control')
        ax.set(xlabel='Retention time (s)',ylabel='Model trapped net charge (fC)',title=f'{d}: PF on / hopping on, actual post-pulse initial states')
        ax.grid(alpha=.25);ax.legend(fontsize=9)
        fig.text(.5,.01,'Exported model data; t=0 omitted on logarithmic axis; transport physics not independently validated.',ha='center',fontsize=8)
        fig.tight_layout(rect=[0,.03,1,1]);fig.savefig(output/f'{d}_post_pulse_retention.png',dpi=170);plt.close(fig)
        fig,axes=plt.subplots(2,2,figsize=(12,8),sharex=True)
        for col,temp in enumerate([77,300]):
            for pf,hop in SWITCHES:
                b=path(d,temp,pf,hop);r=rows(b,'matched_retention');e=rows(b,'matched_empty')
                t=vector(r,'time_s');q=vector(r,'net_C');qe=vector(e,'net_C');contrast=(q-qe)/(q[0]-qe[0]);positive=t>0
                color='tab:orange' if hop else 'tab:blue';ls='--' if pf else '-'
                label=f'PF {"on" if pf else "off"}, hopping {"on" if hop else "off"}'
                axes[0,col].semilogx(t[positive],q[positive]*1e15,color=color,ls=ls,lw=2,label=label)
                axes[1,col].semilogx(t[positive],contrast[positive],color=color,ls=ls,lw=2,label=label)
            axes[0,col].set_title(f'{temp} K, matched seed')
            axes[0,col].set_ylabel('Model trapped net charge (fC)');axes[0,col].legend(fontsize=8)
            axes[0,col].set_ylim(-11.8,.5)
            if d=='TANS' and temp==300:
                axes[0,col].text(1e2,-.30,'Hopping on: final Q = -0.823 fC',fontsize=8)
            axes[1,col].set(xlabel='Retention time (s)',ylabel='Normalized matched-minus-empty contrast',ylim=(-.025,1.025))
            for row in [0,1]:axes[row,col].grid(alpha=.25);axes[row,col].set_xlim(1e-12,3e8)
        fig.suptitle(f'{d}: identical initial fractions, electrons = 0.2 in each layer, holes = 0\nQ0 = -11.21524 fC; exported model comparison, not validated TCAD',fontsize=11)
        fig.tight_layout(rect=[0,0,1,.92]);fig.savefig(output/f'{d}_matched_crosscheck.png',dpi=170);plt.close(fig)
    summary=dict(input_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),case_count=len(metrics),
       unique_matched_initial_fraction_vectors=len(set(initial_vectors)),unique_matched_initial_charges=len(set(initial_q)),
       initial_fraction_vector=initial_vectors[0],initial_charge_C=initial_q[0],all_matched_gate_zero=all_matched_zero_gate,
       all_switch_parameter_checks_pass=all(r['switch_only'] for r in parameter_checks),
       max_state_transfer_charge_error_C=max(r['charge_error_C'] for r in stage_checks),
       max_state_transfer_fraction_error=max(r['max_fraction_error'] for r in stage_checks),
       max_charge_reconstruction_error_C=reconstruction_error,max_DAT_LOG_charge_difference_C=dat_q_error,
       max_DAT_LOG_relative_time_difference=dat_t_relative_error,max_hopping_off_flux=max_off_hop,
       python_source_files=[n for n in z.namelist() if n.endswith('.py')])
    (output/'checks.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    report='''# Retention 교차 검증 보고서

대상: ChargeTrap_77K_Ready_To_Run.zip. 분석일: 2026-11-21.
이 보고서는 기존 계산 로그의 대조와 재그림이다. 전하 수송을 재계산하거나 ATLAS를 실행하지 않았다.

## 핵심 결론

첨부했던 TANS 네 곡선은 PF ON/Hopping ON의 77 K 및 300 K program_retention, erase_retention 파일과 일치한다. matched_retention은 다른 초기 상태의 파일이므로 원래 그래프의 단순 재표시가 아니다.

24개 matched 파일은 같은 초기 점유율 벡터(전자 0.2, 0.2, 0.2, 0.2; 정공 전부 0), 같은 전하 -11.2152364 fC를 사용한다. 각 질화막 영역의 전자 밀도는 1e19 cm^-3, 두께는 1.75 nm이며, 면적은 1 um x 1 um이다. TANS의 온도별 matched 비교는 초기 전하와 공간 분포 차이를 제거한다. 동일한 전계 또는 동일한 자유 캐리어 분포까지 보장하는 것은 아니다.

## 파일명과 온도 구분

폴더의 SONOS/TANOS/TANS와 77K/300K, PF_on/off, Hopping_on/off가 조건을 구분한다. parameters.txt의 temperature와 플래그도 함께 확인했다. 로그 자체에는 별도 온도 열이 없으므로 데이터가 실제 그 온도로 생성됐는지 최종 확정하려면 생성 코드가 필요하다.

- program_netcharge: PGM 펄스 및 종료 구간의 전하.
- erase_netcharge: PGM 결과에서 이어지는 ERS 펄스 및 종료 구간의 전하.
- program_retention: PGM 종료 분포에서 시작하는 0 V 보존.
- erase_retention: ERS 종료 분포에서 시작하는 0 V 보존.
- matched_retention: 동일한 전자 seed 분포에서 시작하는 보존; 실제 PGM/ERS 이력의 대체물이 아님.
- matched_empty: matched 보존의 미충전 대조군.
- pulse_empty: 원래 post-pulse 보존과 비교하는 미충전 대조군. 여기서 pulse라는 파일명만 보고 펄스 구간으로 해석하면 안 된다. 실제 stage는 empty_retention이다.

현재 matched는 전자 seed 검사이다. 동일한 정공 seed/소거 분포에 대한 matched ERS 파일은 없으므로, ERS의 온도 효과를 동일 초기 정공 분포로 분리 검증했다고 주장할 수 없다.

## 상태 전달과 데이터 검사

PGM 끝→ERS 시작, PGM 끝→PGM retention 시작, ERS 끝→ERS retention 시작의 전하뿐 아니라 전자·정공 점유율 8개도 대조했다. 결과는 state_transitions.csv에 기록했다.

각 DAT를 같은 이름 LOG와 대조했고 점유율에서 Q=q*A*sum((p-n)*dy)를 다시 계산했다. 반올림 오차 수준의 일치가 출력 데이터의 내부 일관성을 뒷받침한다. 생성 방정식 또는 시간 적분의 정확성을 보장하지는 않는다.

'''
    report+=table(['검사','값'],[(k,v) for k,v in summary.items() if k!='input_sha256'])
    report+='\n\n입력 ZIP SHA256: `'+summary['input_sha256']+'`\n'
    report+='''

## PF/Hopping ON 조건의 PGM/ERS 및 retention

단위 fC. RET 마지막 시각은 3e8 s이다.

'''
    report+=table(['소자','T(K)','PGM 끝','ERS 끝','PGM RET 끝','ERS RET 끝'],
        [[r['device'],r['temperature_K'],*[f"{r[k]:.7g}" for k in ['PGM_fC','ERS_fC','PGM_RET_final_fC','ERS_RET_final_fC']]]
         for r in metrics if r['pf']==r['hopping']==1])
    report+='''

77 K SONOS의 ERS는 전하를 약간 덜 음으로 만들지만 음의 전하가 대부분 남는다. 소거 방향의 변화는 있으나 완전 소거 성공을 뜻하지 않는다. 77 K TANOS는 거의 중성화되고, 77 K TANS는 양전하 상태까지 넘어간다. TANS의 양전하는 정공 포획/전자 중화 등 모델 성분과 양립하지만 크기와 속도의 타당성은 식 검증이 필요하다.

300 K의 모든 소자에서는 PGM/ERS 후 retention이 공통 음의 값 쪽으로 접근한다. PGM 후 |Q|가 증가하는 경우도 있다. 이는 empty 대조군도 음으로 충전되는 모델 출력과 연결된다. 따라서 raw Q의 최종 절댓값을 원래 프로그램 전하의 보존율이라고 해석할 수 없다.

## 동일 초기 상태 교차 검증

R(t)=[Q_matched(t)-Q_empty(t)]/[Q_matched(0)-Q_empty(0)]를 함께 표시했다. 이는 초기 조건이 다른 두 실행의 순전하 차이가 얼마나 유지되는지 나타내는 진단 지표다. 비선형 모델에서 초기 주입 전자의 생존율, 실제 판독 마진 또는 실험 보존율과 동일하지 않다. empty 대조군과 같은 값에 도달하면 raw Q가 남아도 이 지표는 0에 가깝다.

'''
    report+=table(['소자','T','PF','Hop','최종 Q(fC)','최종 empty Q(fC)','최종 R','R=0.5 첫 시각(s, 근사)'],
        [[r['device'],r['temperature_K'],r['pf'],r['hopping'],f"{r['matched_Qfinal_fC']:.7g}",
          f"{r['empty_Qfinal_fC']:.7g}",f"{r['final_contrast']:.5g}",
          f"{r['contrast_half_time_s']:.5g}" if r['contrast_half_time_s'] is not None else '범위 내 미도달'] for r in metrics])
    report+='''

0.5 도달 시각은 저장 시점 사이를 로그 시간으로 보간한 첫 교차 추정값이다. 시간 적분을 다시 수행한 값이 아니며 출력 간격에 따른 오차가 있다. 끝의 미세한 부호 반전과 1개 기본 전하(1.602e-19 C)보다 매우 작은 값을 물리적 정밀도로 해석하면 안 된다.

## TANS의 구체적 해석

77 K matched에서는 hopping을 고정하면 PF ON/OFF의 Q(t)가 기록된 정밀도에서 완전히 같다. hopping OFF는 최종 약 -5.607536 fC, ON은 사실상 0이다. 동일 초기 조건에서도 hopping 스위치가 결과에 영향을 준다는 의미다. hopping 자체가 총전하를 소멸시킨다는 증거는 아니며, 내부 이동과 경계 탈출의 결합을 검증해야 한다.

300 K에서 hopping OFF는 PF를 켜면 raw Q 및 대조군과의 차이가 달라진다. hopping ON에서는 PF ON/OFF의 Q 차이가 매우 작다. PF가 단독으로 큰 효과를 내지 않는 조건도 존재하므로, ON이면 반드시 큰 차이가 보여야 한다고 판단하면 안 된다.

PF ON/Hopping ON에서 1 s의 matched-minus-empty 정규화 차이는 77 K 약 0.418874, 300 K 약 0.028034이다. 1000 s에는 각각 약 0.114771 및 수치적으로 0이다. 이 조건의 모델에서는 동일 초기 상태의 차이가 300 K에서 더 빨리 사라진다.

PF ON/Hopping ON의 실제 PGM 상태는 77 K TANS에서 +16 V 끝의 Q=-0.357128 fC가 1 ns 하강 구간 후 -4.496387 fC가 된다. 최종 전하 대부분이 종료 파형에 민감할 수 있다. 이는 자동으로 오류를 뜻하지 않지만, 상승/하강 시간과 시간 적분 수렴 검증이 필요하다. matched 검사가 이 펄스 민감도 문제를 검증하거나 제거해 주는 것은 아니다.

## 물리적 타당성의 판정 범위

확인됨: 설정 기록의 통제, 초기 조건 동일성, 상태 전달, DAT/LOG 대응, 전하 합산, hopping OFF의 유량 0, PF/Hopping 설정에 따른 출력 차이.

미확정: 실제 국소 전계에 따른 PF 장벽 저하 식, FN/직접 터널링 구분, hopping 정·역방향 전이율과 detailed balance, 닫힌 경계에서 내부 hopping의 전하 보존, 공간/시간 수렴, 300 K 미충전 상태의 자발적 음전하 축적에 대한 실제 소자 근거.

외부 데이터의 PF/Hopping ON 표시는 ATLAS 내부 모델 활성화와 다르다. 현재 .in은 고정 ox.charge를 넣어 읽는 덱이며, 해당 외부 수송 모델이 실제 ATLAS 2015에서 실행된 증거가 아니다. 생성 Python 원본이 없어 물리 모델 구현 성공률을 수치로 부여하지 않는다.

## 그래프 읽는 법

*_post_pulse_retention.png: 실제 PGM/ERS 후 상태에서 시작하는 네 곡선과 300 K 미충전 대조군. 이는 기존 TANS 원본 그림의 대응 데이터이며 matched가 아니다.

*_matched_crosscheck.png: 위쪽은 동일 seed의 raw Q, 아래쪽은 matched-minus-empty 정규화 차이. 파랑은 hopping OFF, 주황은 ON, 실선 PF OFF, 점선 ON. 곡선이 겹칠 수 있다. 모든 그래프는 t>0만 사용하고 y는 선형 fC, x는 로그 초 단위다.

case_metrics.csv: 조건별 원시 끝값과 선택 시점 값. parameter_checks.csv: 같은 소자·온도 안에서 pf/hopping 외 파라미터가 바뀌는지. checks.json: 검사 요약과 입력 해시. retention_crosscheck.py: 재현용 검사/그래프 코드.
'''
    (output/'Retention_Review_KO.md').write_text(report,encoding='utf-8')
    print(json.dumps(summary,indent=2))
    print('PF ON / HOPPING ON METRICS')
    for r in metrics:
        if r['pf']==r['hopping']==1:
            print(r['device'],r['temperature_K'],'R1s',r['contrast_at_1s'],'Rfinal',r['final_contrast'],'half',r['contrast_half_time_s'])


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('archive',type=Path)
    ap.add_argument('--output',type=Path,default=Path('retention_review'))
    args=ap.parse_args()
    run(args.archive,args.output)
